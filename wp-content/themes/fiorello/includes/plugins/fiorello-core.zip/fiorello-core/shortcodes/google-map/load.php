<?php

include_once FIORELLO_CORE_SHORTCODES_PATH . '/google-map/functions.php';
include_once FIORELLO_CORE_SHORTCODES_PATH . '/google-map/google-map.php';