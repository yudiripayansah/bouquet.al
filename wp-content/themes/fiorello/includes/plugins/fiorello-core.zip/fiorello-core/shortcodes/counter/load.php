<?php

include_once FIORELLO_CORE_SHORTCODES_PATH . '/counter/functions.php';
include_once FIORELLO_CORE_SHORTCODES_PATH . '/counter/counter.php';