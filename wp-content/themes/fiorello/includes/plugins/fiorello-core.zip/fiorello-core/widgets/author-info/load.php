<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/author-info/functions.php';
require_once FIORELLO_CORE_ABS_PATH . '/widgets/author-info/author-info.php';